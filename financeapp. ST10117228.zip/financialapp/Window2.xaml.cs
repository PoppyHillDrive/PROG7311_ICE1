﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace financialapp
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public const String con = "Data Source=.;Initial Catalog=FinanceDB;Integrated Security=True";
        public Window2()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            public static int SaveData<T>(String Sql, T data)
            {
                using (IDbConnection cnn = new SqlConnection(Connections.con))
                {
                    return cnn.Execute(Sql, data);
                }
            }

            public static List<ScheduleModel> LoadSchedule()
            {
                String sql = @"select Type,Sender,Recipient,Amount,Date from dbo.Transactions;";

                return SqlDataAccess.LoadData<ScheduleModel>(sql);
            }
        }
    }
}
