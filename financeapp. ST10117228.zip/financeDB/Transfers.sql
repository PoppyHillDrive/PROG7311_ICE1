﻿CREATE TABLE [dbo].[Transfers]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Type] VARCHAR(100) NOT NULL, 
    [Sender] VARCHAR(100) NOT NULL, 
    [Recipient] VARCHAR(100) NOT NULL, 
    [Amount] INT NOT NULL, 
    [Date] VARCHAR(100) NOT NULL
)
