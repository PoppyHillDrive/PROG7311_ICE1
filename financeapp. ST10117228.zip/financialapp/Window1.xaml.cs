﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace financialapp
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        String Type = "";
        String Sender = "";
        String Recipient = "";
        double Amount = 0;
        String Date = "";

        public const String con = "Data Source=.;Initial Catalog=FinanceDB;Integrated Security=True";
        public Window1()
        {
            InitializeComponent();
        }

       

        public static List<T> LoadData<T>(String Sql)
        {
            using (IDbConnection cnn = new SqlConnection(Connections.con))
            {
                return cnn.Query<T>(Sql).ToList();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            String Type = Convert.ToString(type.Text);
            String Sender = Convert.ToString(send.Text);
            String Recipient = Convert.ToString(recipient.Text);
            double Amount = Convert.ToDouble(amount.Text);
            String Date = Convert.ToString(date.Text);

            Window2 w2 = new Window2();
            w2.Show();

            MessageBox.Show("Transfer was sucessful");

            String sql = @"insert into dbo.Transactions (Type,Sender,Recipient,Amount,Date)
                           values (@Type,@Sender,@Recipient,@Amount,@Date);";

            return SqlDataAccess.SaveData(sql, data);
        }
    }
}
    